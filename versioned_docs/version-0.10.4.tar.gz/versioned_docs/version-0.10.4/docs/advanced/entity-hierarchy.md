---
title: Entity Hierarchy
slug: /advanced/entity-hierarchy
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/advanced/entity-hierarchy.md
---

# Entity Hierarchy

WIP
